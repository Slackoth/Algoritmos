#ifndef STACK
#define STACK

#include <iostream>

template<class T>
struct Node {
    T data;
    Node* next;

    Node() { next = NULL; }
};

template<class T>
int size(Node<T>* stack) {
    return stack ? 1 + size(stack->next) : 0;
}

template<class T>
bool empty(Node<T>* stack) {
    return stack == NULL;
}

template<class T>
Node<T>* top(Node<T>* stack) {
    Node<T>* top = new Node<T>;
    top->data = stack->data;

    return top;
}

template<class T>
void push(Node<T>** stack, T data) {
    Node<T>* newNode = new Node<T>();
    newNode->data = data;
    newNode->next = *stack;
    *stack = newNode;
}

template<class T>
Node<T>* pop(Node<T>** stack) {
    Node<T>* popped = new Node<T>;
    Node<T>* aux = *stack;
    popped->data = (*stack)->data;
    *stack = (*stack)->next;

    delete(aux);
    return popped;
}

template<class T>
void traverseStack(Node<T>* stack) {
    if(stack) {
        std::cout << stack->data << "\t";
        return traverseStack(stack->next);
    }
}

#endif