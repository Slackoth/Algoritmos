#include <cmath>
#include <string>
#include "Stack.h"
#include <iomanip>
#include <iostream>

using namespace std;

bool isDigit(char c) {
    return (c >= '0' && c <= '9');
}

bool isOperator(char c) {
    switch (c) {
        case '(':
        case ')':
        case '^':
        case '/':
        case '*':
        case '+':
        case '-':
            return true;

        default: return false;
    }
}

int getPrecedence(char c) {
    switch (c) {
        case '+':
        case '-':
            return 1;

        case '*': return 2;
        case '/': return 3;

        case '^': return 4;

        case '(':
        case ')':
            return 5;

        default: return -1;
    }
}

//template<class Num>
float operate(float a, float b, char op) {
    switch (op) {
        case '+': return a + b;

        case '-': return a - b;

        case '*': return a * b;

        case '/':
            if(b == 0)
                throw runtime_error("Math error: Attempted to divide by zero.\n");
            else
                return a / b;

        case '^': return pow(a, b);

        default: return -1;
    }

    return -1;
}

int main() {
    //works: string operation = "4.5+3*5.75/1";
    //works: string operation = "4.5/3*5.75+1";
    works: string operation = "4.5^3/5.75*1";
    //string operation = "-1*4";
    Node<float>* floats = NULL;
    Node<char>* chars = NULL;
    int length = operation.length(), start = 0;
    float value = 0.0;

    for(int i = 0; i < length; i++) {
        char currentSpot = operation[i];
        
        if(isOperator(currentSpot)) {
            value = stof(operation.substr(start, i));
            cout << "value: " << value << "\n";

            push(&floats, value);

            if(empty(chars)) {
                //value = 0.0;

                push(&chars, currentSpot);
            }
            else {
                Node<char>* prev = top(chars);
                cout << "char->prev->data: " << prev->data << "\n";
                //cout << "current->data: " << value << "\n";

                if(getPrecedence(prev->data) >= getPrecedence(currentSpot)) {
                    float b = pop(&floats)->data;
                    float a = pop(&floats)->data;
                    char op = pop(&chars)->data;

                    value = operate(a, b, op);
                    cout << "valuePrecedence: " << value << "\n";

                    push(&floats, value);
                    push(&chars, currentSpot);

                    //value = 0.0;
                }
                else {
                    push(&chars, currentSpot);

                    //value = 0.0;
                }
            }
            value = 0.0;
            cout << "start: " << i + 1 << "\n";
            start = i + 1;
        }
        else if(i + 1 >= length) {
            cout << "start: " << start << "\n";
            value = stof(operation.substr(start, i));
            push(&floats, value);
            cout << "lastValue: " << value << "\n";
            start = 0;
        }
    }

    traverseStack(floats);
    cout << "\n";
    traverseStack(chars);
    cout << "\n";

    while (!empty(chars)) {
        float b = pop(&floats)->data;
        float a = pop(&floats)->data;
        char op = pop(&chars)->data;

        float value = operate(a, b, op);
        cout << "value: " << value << "\n";

        push(&floats, value);
    }

    cout << "Result: " << setprecision(9) << top(floats)->data << "\n";
    
    return 0;
}